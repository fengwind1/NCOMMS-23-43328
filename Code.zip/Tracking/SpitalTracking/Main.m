%{
===================
Author: Xiaopeng Feng
Date: 2023/12/03
===================
%}
%% Input data
clc; clear all;
input = load('input.txt');
output = load('output.txt');
Fin = BystrainXYZ(input,output);
%% Prediction
testgroup =  load('testgroup.txt');
testn = size(testgroup,1);
mtest = localXYZ(testgroup');
mtest=abs(mtest);
mtest = mtest';
tracetest1 = zeros(20,20);
tracetest2 = zeros(20,20);
tracetest3 = zeros(20,20);
tracetest4 = zeros(20,20);
 Imgfile = sprintf('TraceXYZimg');
 mkdir(Imgfile);
tracerecord=[];
figure,
for n = 1:testn;
xx = round(mtest(n,1));
yy = round(mtest(n,2));
zz = round(mtest(n,3));
 if xx<=0||xx>20; xx = 1;end
 if yy<=0||xx>20; yy = 1;end
 if zz<=0; zz = 1;end
if zz ==1;tracetest1(xx,yy)=1;end
if zz ==2;tracetest2(xx,yy)=1;end
if zz ==3;tracetest3(xx,yy)=1;end
if zz ==4;tracetest4(xx,yy)=1;end
tracerecord = [tracerecord;xx,yy,zz];
 subplot(1,2,1),scatter3(tracerecord(:,1),tracerecord(:,2),tracerecord(:,3),50,'o');xlim([0 20]);ylim([0 20]);zlim([0 3]);
 xlabel('X');ylabel('Y');zlabel('Z');
% axis off;
hold on;
frame = getframe(gcf);
im = frame2im(frame);
 name = [num2str(n,'%04d'),'trace','.png']
 imgFilePath = fullfile(Imgfile, name);
        imwrite(im,imgFilePath);
 %close frame;
end
%% Generating the reference trace
 C = size(tracerecord,1);
 tracerecordr = [];
 for i = 5:15;
     tracerecordr = [tracerecordr;i,5,1];
 end
 for i = 5:15;
     tracerecordr = [tracerecordr;15,i,1];
 end
 for i = 1:10;
     k = 15-i;
     tracerecordr = [tracerecordr;k,15,3];
 end
 for i = 1:10;
     k = 15-i;
     tracerecordr = [tracerecordr;5,k,3];
 end
  C = size(tracerecordr,1);
subplot(1,2,2), scatter3(tracerecordr(:,1),tracerecordr(:,2),tracerecordr(:,3),50,'o');colormap jet;xlim([0 20]);ylim([0 20]);zlim([0 3]);
 xlabel('X');ylabel('Y');zlabel('Z');
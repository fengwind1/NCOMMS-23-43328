# MATLAB Trajectory Tracking Code

## Introduction
This MATLAB code is designed for trajectory tracking, utilizing various scripts and functions. The primary script, `Main.m`, is responsible for executing the trajectory tracking process. It begins by training on the `traindata`, then validates and reproduces trajectories using the `testgroup`. 

## Code Components

### Main.m
The main script for trajectory tracking. It first reads and trains on the `traindata`, then validates and reproduces trajectories using the `testgroup`. Note that running `Main.m` re-trains the model each time, leading to slight variations in the output trajectories.

### Array_data_treat Function
This function, `Array_data_treat`, is responsible for processing and cropping raw data, allowing for efficient handling of the original data.

### Bystrain Function
The `Bystrain` function trains the data model using Bayesian orthogonalization, contributing to the trajectory tracking process.

### Local Function
The `local` function is involved in training the model through Bayesian regularization, enhancing the trajectory tracking capabilities.

## Data Description

### traindata
The raw training data consists of 8 columns, each representing signals from detectors of 8 different reading devices. These signals originate from 8 pixels.

### testgroup
Similar to `traindata`, `testgroup` is acquired through the same method, but it represents data obtained under the illumination of a light source moving along a specific trajectory.

## Note
As the `Main` function retrains the model with each run, there may be variations in the final output trajectories. Improving the precision of signal reading and the stability of the LED light source can further enhance the consistency of the results.
For both color recognition and spatial trajectory tracking codes, the approach is similar. 
## Dependencies
- MATLAB R2022 or later

## Contributors
- Xiaopeng Feng

Feel free to reach out for any questions or issues!
%{
===================
Author: Xiaopeng Feng
Date: 2023/12/03
===================
%}
clc;
clear all;
%% Input traingroup
input = load('input.txt');
output = load('output.txt');
Fin = Bystraincolor(input, output);

%% Prediction
    testgroup = load('testgroup.txt');
    mtest = abs(localcolor(testgroup'));
    mtest = round(mtest)';
    tracetest = zeros(20, 20, 3);
%% Result output
Imgfile = sprintf('Tracecolorimg');
mkdir(Imgfile);
    for n = 1:size(mtest, 1)
        xx = max(1, min(20, mtest(n, 1)));
        yy = max(1, min(20, mtest(n, 2)));
         tracetest(yy, xx, :) = [0, 0, 0];
         if mtest(n,3)==1;
             tracetest(yy, xx, 1) = 1;
         else if mtest(n,3) ==2;
                 tracetest(yy, xx, 2) = 1;
                 else if mtest(n,3) ==3;
                 tracetest(yy, xx, 3) = 1;
                 end
         end
         end
         name = [num2str(n,'%04d'), 'trace.png'];
        imgFilePath = fullfile('Tracecolorimg', name);
        imwrite(tracetest, imgFilePath);
    end
figure,
imagesc(tracetest); axis image; axis off;
function Df = Array_data_treat(D)
D(size(D,1),:)=[];
for i = 2:2:size(D,2)
D(:,i) = flip(D(:,i));
end
D = D-min(min(D));
Df = D;
end


%{
===================
Author: Xiaopeng Feng
Date: 2023/12/03
===================
%}
%% Load data
clc; clear all;
traindata = load('traindata.txt');
smooth = 1;

if smooth == 1
    traindata = smoothdata(traindata, 1, 'movmean', 6);
end

step = 21;

directions = {'0°', '45°', '90°', '135°', '180°', '225°', '270°', '315°'};
D = cell(1, 8);
dc = zeros(1, 8);

for i = 1:8
    D{i} = Array_data_treat(reshape(traindata(:, i), step, step-1));
    dc(i) = min(min(reshape(traindata(:, i), step, step-1)));
end

% Plot matrices
figure;

for i = 1:8
    subplot(4, 2, i);
    imagesc(D{i});
    axis image;
    colormap jet;
    axis off;
    title(directions{i});
end

% Create datasheet
datasheet = [];

for i = 1:size(D{1}, 1)
    for j = 1:size(D{1}, 2)
        data_row = [i, j];
        for k = 1:8
            data_row = [data_row, D{k}(i, j)];
        end
        datasheet = [datasheet; data_row];
    end
end

input = datasheet(:, 3:10);
inputnor = input ./ max(input, [], 2);
output = datasheet(:, 1:2);

% Perform further processing (assuming Bystrain is a function)
Fin = Bystrain(inputnor, output);

% Load testgroup data
testgroup = load('testgroup.txt');

if smooth == 1
    testgroup = smoothdata(testgroup, 1, 'movmean', 6);
end

% Subtract dc from testgroup
for i = 1:8
    testgroup(:, i) = testgroup(:, i) - dc(i);
end

testgroup = abs(testgroup);
testn = size(testgroup, 1);
testgroupnor = testgroup ./ max(testgroup, [], 2);
mtest = local(testgroupnor');
mtest = mtest';
mtest = abs(mtest);
tracetest = zeros(20, 20);
tracedis = zeros(20, 20);
Imgfile = 'Traceimg';
mkdir(Imgfile);

for n = 1:testn
    xx = round(mtest(n, 1));
    yy = round(mtest(n, 2));
    xx = max(1, min(xx, 20));
    yy = max(1, min(yy, 20));
    
    if n > 5 && n < testn - 5
        tracetest(yy, xx) = 1;
        tracerecover = fliplr(tracetest);
        name = [num2str(n, '%04d'), 'trace', '.png'];
        imgFilePath = fullfile(Imgfile, name);
        imwrite(tracerecover, imgFilePath);
    end
end

figure;
imagesc(tracerecover);
axis image;
colormap gray;
axis off;

function Fin = Bystrain(input,output)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
x = input';
t = output';
trainFcn = 'trainbr'
hiddenLayerSize = 10;
net = fitnet(hiddenLayerSize,trainFcn);
net.input.processFcns = {'removeconstantrows','mapminmax'};
net.output.processFcns = {'removeconstantrows','mapminmax'};
net.divideFcn = 'dividerand'; 
net.divideMode = 'sample';
net.divideParam.trainRatio = 98/100;
net.divideParam.valRatio = 1/100;
net.divideParam.testRatio = 1/100;
net.performFcn = 'mse'; 
net.plotFcns = {'plotperform','plottrainstate','ploterrhist', ...
    'plotregression', 'plotfit'};
[net,tr] = train(net,x,t);
y = net(x);
e = gsubtract(t,y);
performance = perform(net,t,y)
trainTargets = t .* tr.trainMask{1};
valTargets = t .* tr.valMask{1};
testTargets = t .* tr.testMask{1};
trainPerformance = perform(net,trainTargets,y)
valPerformance = perform(net,valTargets,y)
testPerformance = perform(net,testTargets,y)
%view(net)
%if (false)
    genFunction(net,'local');
    y = local(x); Fin = 1;
 %   end
if (false)
    genFunction(net,'local','MatrixOnly','yes');
    y = local(x);
end
if (false)
    gensim(net);
end
end


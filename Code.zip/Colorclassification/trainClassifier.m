function [trainedClassifier, validationAccuracy] = trainClassifier(trainingData)

% Generated automatically by MATLAB

% 
% The following code processes the data into a suitable shape to train the model
%
inputTable = trainingData;
predictorNames = {'Var1', 'Var2', 'Var3', 'Var4', 'Var5', 'Var6', 'Var7', 'Var8', 'Var9'};
predictors = inputTable(:, predictorNames);
response = inputTable.Var10;
isCategoricalPredictor = [false, false, false, false, false, false, false, false, false];
classNames = [1; 2; 3; 4; 5];

% training classifier
% The following code specifies all classifier options and trains the classifier.
classificationKNN = fitcknn(...
    predictors, ...
    response, ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 1, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', classNames);

% Use the predict function to create the result structure
predictorExtractionFcn = @(t) t(:, predictorNames);
knnPredictFcn = @(x) predict(classificationKNN, x);
trainedClassifier.predictFcn = @(x) knnPredictFcn(predictorExtractionFcn(x));

% Adds a field to the result structure
trainedClassifier.RequiredVariables = {'Var1', 'Var2', 'Var3', 'Var4', 'Var5', 'Var6', 'Var7', 'Var8', 'Var9'};
trainedClassifier.ClassificationKNN = classificationKNN;
trainedClassifier.About = 'This structure is a training model derived from the classification learner R2023b.';
trainedClassifier.HowToPredict = sprintf('To make predictions on the new table T, use the following: \n [yfit,scores] = c.predictFcn(T) \n <a href="matlab:helpview(fullfile(docroot, ''stats'', ''stats.map''), ''appclassification_exportmodeltoworkspace'')">How to predict using an exported model</a>。');

% Extract predictor variables and responses
% The following code processes the data into a suitable shape to train the model.
%
inputTable = trainingData;
predictorNames = {'Var1', 'Var2', 'Var3', 'Var4', 'Var5', 'Var6', 'Var7', 'Var8', 'Var9'};
predictors = inputTable(:, predictorNames);
response = inputTable.Var10;
isCategoricalPredictor = [false, false, false, false, false, false, false, false, false];
classNames = [1; 2; 3; 4; 5];

% Perform cross validation
partitionedModel = crossval(trainedClassifier.ClassificationKNN, 'KFold', 5);

% Computational verification prediction
[validationPredictions, validationScores] = kfoldPredict(partitionedModel);

% Computational validation accuracy
validationAccuracy = 1 - kfoldLoss(partitionedModel, 'LossFun', 'ClassifError');

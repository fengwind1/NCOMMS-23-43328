%{
===================
Author: Xiaopeng Feng
Date: 2023/12/03
===================
%}
%% Load data
clear all; clc;
load(['datacut1.txt']);
dataave = zeros(size(datacut1)); 
datacut = cell(1, 9);
datara = cell(1, 9);
for i = 1:9   
    datacut{i} = load(['datacut' num2str(i) '.txt']);
    datacut{i} = wiener2(datacut{i}, [6 6]);
    disp(['Size of datacut' num2str(i) ': ' num2str(size(datacut{i}))]);
     if i < 9
         datacut0 = datacut{i};
         dataave = dataave + datacut0;
     end
end
dataave = dataave / 9;

%% Weight value calculation and Linear weighting
for i = 1:9
    k(i) = median(datacut{i}) / median(dataave);
end

for i = 1:9
    index1 = mod(i, 9) + 1;
    index2 = mod(i + 1, 9) + 1;
    datara{i} = datacut{i} + datacut{index1} .* k(i) / k(index1) + datacut{index2} .* k(i) / k(index2);
    % datara{i} = mean(cat(3, datacut{:}), 3);
end



%% Background calculation
rowb = size(dataave,1);
colb = size(dataave,2);
backline = dataave(2,:)+dataave(rowb-2,:)./2;
backgroundfit = polyfit(1:colb,backline,2);
x = 1:colb;
y = backgroundfit(1).*x.^2+backgroundfit(2).*x+backgroundfit(3);
y = y./max(y);
%plot(x,y); title ('Calibration curve'); xlabel('pixels'); ylabel('Intensity (a.u.)');
background = [];
for i = 1:rowb
background = [background;y];
end



%% Background Calibration
for i = 1:9
    datara{i} = datara{i} ./ background ./ max(max(datara{9}));
end
% datara{i} = datara{i} / background / max(max(datara{i}));

%% Image preview
figure('Name', 'Before optimization');
subplot_titles = {'-0.1 V', '-0.2 V', '-0.3 V', '-0.4 V', '-0.5 V', '-0.6 V', '-0.7 V', '-0.8 V', '-0.9 V'};
for i = 1:9
    subplot(2, 5, i);
    imagesc(datacut{i}, [0, 5]); axis image; colormap gray; axis off; title(subplot_titles{i});
end
subplot(2, 5, 10);imagesc(dataave, [0, 5]); axis image; colormap gray; axis off; title('Average');
figure('Name', 'After optimization');
for i = 1:9
    subplot(2, 5, i);
    imagesc(datara{i}, [0, 0.6]); axis image; colormap gray; axis off; title(subplot_titles{i});
end
subplot(2, 5, 10);imagesc(dataave, [0, 5]); axis image; colormap gray; axis off; title('Average');
%% Sample point extraction
step = 5;
%[X, Y] = meshgrid(-step:step, -step:step);
sample_points = [31, 36; 31, 79; 27, 120; 70, 36; 135, 40];
u = cell(1, 9);
for i = 1:9
    for j = 1:5
    u{i} = [u{i};reshape(datara{i}(sample_points(j,1)-step:sample_points(j,1)+step,sample_points(j,2)-step:sample_points(j,2)+step),[(step*2+1)^2,1])];
        end
end

%% Input generation
v = repelem(1:5, (step * 2 + 1)^2)';
input = table(u{:}, v);
trainedModel = trainClassifier(input);
%% Output 
col = size(dataave, 2);
row = size(dataave, 1);

color_map = [
    1.0 0 0;   % Red
    0 1.0 0;   % Green
    0 0 1.0;   % Blue
    1.0 1.0 0; % Yellow
    0 0 0      % Black
];

colorx = zeros(row, col, 3);

for i = 1:row
    for j = 1:col
        ut = [datara{1}(i,j), datara{2}(i,j), datara{3}(i,j), datara{4}(i,j), datara{5}(i,j),datara{6}(i,j), datara{7}(i,j), datara{8}(i,j), datara{9}(i,j)];
        pre = array2table(ut, 'VariableNames', {'Var1','Var2','Var3','Var4','Var5','Var6','Var7','Var8','Var9'});
        yfit = trainedModel.predictFcn(pre);
        colorx(i, j, :) = color_map(yfit, :);
    end
end
figure,
imagesc(colorx); title('Colorclassification result')
axis image;
axis off;